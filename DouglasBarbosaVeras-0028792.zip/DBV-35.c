// DBV-35.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-35 - Exibe os n primeiros termos da sequencia de Fibonacci  *");
    printf("\n***************************************************************************\n");

    int n, i;
    long long a = 0, b = 1, proximo;

    printf("\nInforme quantos termos deseja exibir: ");
    scanf("%d", &n);

    printf("\nSequencia de Fibonacci:\n");
    for (i = 1; i <= n; i++) {
        printf("%lld ", a);
        proximo = a + b;
        a = b;
        b = proximo;
    }
    printf("\n");

    return 0;
}
