// DBV-59.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-59 - Assistente de direcao do robo de entregas (switch)     *");
    printf("\n***************************************************************************\n");

    char direcao;

    printf("\nDigite a direcao (N, S, L, O): ");
    scanf(" %c", &direcao);

    switch (direcao) {
        case 'N':
            printf("\nSeguir para o Norte.\n");
            break;
        case 'S':
            printf("\nSeguir para o Sul.\n");
            break;
        case 'L':
            printf("\nVirar a Leste (Direita).\n");
            break;
        case 'O':
            printf("\nVirar a Oeste (Esquerda).\n");
            break;
        default:
            printf("\nComando invalido! Pare o robo.\n");
    }

    return 0;
}
