// DBV-48.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-48 - Menu com opcao de sair utilizando do...while           *");
    printf("\n***************************************************************************\n");

    int opcao;

    do {
        printf("\n1 - Mensagem\n");
        printf("2 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if (opcao == 1) {
            printf("\nVoce escolheu a mensagem!\n");
        }
    } while (opcao != 2);

    printf("\nSaindo do programa...\n");

    return 0;
}
