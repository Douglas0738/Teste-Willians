// DBV-16.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-16 - Verifica se o pedido eh multiplo de 3 e/ou 5           *");
    printf("\n***************************************************************************\n");

    int pedido;

    printf("\nInforme o numero do pedido: ");
    scanf("%d", &pedido);

    if (pedido % 3 == 0 && pedido % 5 == 0) {
        printf("\nParabens! Voce ganhou um refrigerante e uma sobremesa!\n");
    } else if (pedido % 3 == 0) {
        printf("\nParabens! Voce ganhou um refrigerante!\n");
    } else if (pedido % 5 == 0) {
        printf("\nParabens! Voce ganhou uma sobremesa!\n");
    } else {
        printf("\nEste pedido nao se enquadrou na promocao.\n");
    }

    return 0;
}
