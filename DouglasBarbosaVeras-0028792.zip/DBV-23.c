// DBV-23.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-23 - Identifica a maior pontuacao entre dois atletas        *");
    printf("\n***************************************************************************\n");

    float pontuacao1, pontuacao2;

    printf("\nInforme a pontuacao do atleta 1: ");
    scanf("%f", &pontuacao1);
    printf("Informe a pontuacao do atleta 2: ");
    scanf("%f", &pontuacao2);

    if (pontuacao1 > pontuacao2) {
        printf("\nO atleta 1 teve a maior pontuacao (%.2f).\n", pontuacao1);
    } else if (pontuacao2 > pontuacao1) {
        printf("\nO atleta 2 teve a maior pontuacao (%.2f).\n", pontuacao2);
    } else {
        printf("\nOs dois atletas tiveram a mesma pontuacao (%.2f).\n", pontuacao1);
    }

    return 0;
}
