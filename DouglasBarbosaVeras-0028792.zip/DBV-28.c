// DBV-28.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-28 - Soma dos 100 primeiros numeros naturais usando for     *");
    printf("\n***************************************************************************\n");

    int i, soma = 0;

    for (i = 1; i <= 100; i++) {
        soma += i;
    }

    printf("\nA soma dos 100 primeiros numeros naturais e: %d\n", soma);

    return 0;
}
