// DBV-45.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-45 - Exibe um menu repetidamente at o usuario escolher sair *");
    printf("\n***************************************************************************\n");

    int opcao = -1;

    while (opcao != 0) {
        printf("\n--- MENU ---\n");
        printf("1 - Consultar saldo\n");
        printf("2 - Realizar deposito\n");
        printf("0 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if (opcao == 1) {
            printf("\nSaldo atual: R$ 1500,00\n");
        } else if (opcao == 2) {
            printf("\nDeposito realizado com sucesso!\n");
        } else if (opcao != 0) {
            printf("\nOpcao invalida!\n");
        }
    }

    printf("\nSaindo do sistema...\n");

    return 0;
}
