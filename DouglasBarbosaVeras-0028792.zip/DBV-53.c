// DBV-53.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-53 - Menu de cadastro com confirmacao de saida usando 's'   *");
    printf("\n***************************************************************************\n");

    char resposta;

    do {
        printf("\n--- Sistema de Cadastro ---\n");
        printf("Operacao realizada com sucesso!\n");
        printf("\nDeseja sair? (s/n): ");
        scanf(" %c", &resposta);
    } while (resposta != 's' && resposta != 'S');

    printf("\nSaindo do sistema de cadastro...\n");

    return 0;
}
