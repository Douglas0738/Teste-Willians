// DBV-39.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-39 - Pede um numero positivo repetidamente usando while     *");
    printf("\n***************************************************************************\n");

    int numero;

    printf("\nDigite um numero positivo: ");
    scanf("%d", &numero);

    while (numero <= 0) {
        printf("Valor invalido! Digite um numero positivo: ");
        scanf("%d", &numero);
    }

    printf("\nNumero positivo recebido: %d\n", numero);

    return 0;
}
