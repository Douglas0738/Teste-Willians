// DBV-25.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-25 - Verifica aprovacao do aluno a partir da media final    *");
    printf("\n***************************************************************************\n");

    float media;

    printf("\nInforme a media final do aluno: ");
    scanf("%f", &media);

    if (media >= 6.0) {
        printf("\nAluno APROVADO.\n");
    } else if (media >= 4.0) {
        printf("\nAluno em RECUPERACAO.\n");
    } else {
        printf("\nAluno REPROVADO.\n");
    }

    return 0;
}
