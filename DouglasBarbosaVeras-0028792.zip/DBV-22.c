// DBV-22.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-22 - Verifica se um numero e par ou impar                   *");
    printf("\n***************************************************************************\n");

    int numero;

    printf("\nInforme um numero: ");
    scanf("%d", &numero);

    if (numero % 2 == 0) {
        printf("\nO numero %d eh PAR.\n", numero);
    } else {
        printf("\nO numero %d eh IMPAR.\n", numero);
    }

    return 0;
}
