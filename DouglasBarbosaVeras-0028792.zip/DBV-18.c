// DBV-18.c
#include <stdio.h>
#include <string.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-18 - Login simples para acesso a biblioteca digital         *");
    printf("\n***************************************************************************\n");

    char usuario[30], senha[30];
    const char USUARIO_CORRETO[] = "aluno";
    const char SENHA_CORRETA[] = "1234";

    printf("\nDigite o usuario: ");
    scanf("%s", usuario);
    printf("Digite a senha: ");
    scanf("%s", senha);

    if (strcmp(usuario, USUARIO_CORRETO) == 0 && strcmp(senha, SENHA_CORRETA) == 0) {
        printf("\nAcesso PERMITIDO! Bem-vindo a biblioteca digital.\n");
    } else {
        printf("\nAcesso NEGADO! Usuario ou senha incorretos.\n");
    }

    return 0;
}
