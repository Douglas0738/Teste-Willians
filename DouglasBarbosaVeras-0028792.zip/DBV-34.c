// DBV-34.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-34 - Verifica se um numero e primo utilizando for           *");
    printf("\n***************************************************************************\n");

    int numero, i, ehPrimo = 1;

    printf("\nInforme um numero: ");
    scanf("%d", &numero);

    if (numero < 2) {
        ehPrimo = 0;
    } else {
        for (i = 2; i < numero; i++) {
            if (numero % i == 0) {
                ehPrimo = 0;
            }
        }
    }

    if (ehPrimo) {
        printf("\nO numero %d e PRIMO.\n", numero);
    } else {
        printf("\nO numero %d NAO e primo.\n", numero);
    }

    return 0;
}
