// DBV-40.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-40 - Exibe a tabuada de um numero utilizando while          *");
    printf("\n***************************************************************************\n");

    int numero, i = 1;

    printf("\nInforme um numero: ");
    scanf("%d", &numero);

    printf("\nTabuada do %d:\n", numero);
    while (i <= 10) {
        printf("%d x %d = %d\n", numero, i, numero * i);
        i++;
    }

    return 0;
}
