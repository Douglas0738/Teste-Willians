// DBV-41.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-41 - Verifica se um numero e primo utilizando while         *");
    printf("\n***************************************************************************\n");

    int numero, i = 2, ehPrimo = 1;

    printf("\nInforme um numero: ");
    scanf("%d", &numero);

    if (numero < 2) {
        ehPrimo = 0;
    } else {
        while (i < numero) {
            if (numero % i == 0) {
                ehPrimo = 0;
            }
            i++;
        }
    }

    if (ehPrimo) {
        printf("\nO numero %d e PRIMO.\n", numero);
    } else {
        printf("\nO numero %d NAO e primo.\n", numero);
    }

    return 0;
}
