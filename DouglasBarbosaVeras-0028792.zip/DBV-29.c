// DBV-29.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-29 - Exibe os numeros pares entre 0 e 50 usando for         *");
    printf("\n***************************************************************************\n\n");

    int i;

    for (i = 0; i <= 50; i += 2) {
        printf("%d\n", i);
    }

    return 0;
}
