// DBV-20.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-20 - Verifica se um ano e bissexto                          *");
    printf("\n***************************************************************************\n");

    int ano;

    printf("\nInforme o ano: ");
    scanf("%d", &ano);

    if ((ano % 4 == 0 && ano % 100 != 0) || ano % 400 == 0) {
        printf("\nO ano %d eh BISSEXTO (366 dias).\n", ano);
    } else {
        printf("\nO ano %d NAO eh bissexto (365 dias).\n", ano);
    }

    return 0;
}
