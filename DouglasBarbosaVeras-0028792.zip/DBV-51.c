// DBV-51.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-51 - Contagem regressiva de 10 a 1 utilizando do...while    *");
    printf("\n***************************************************************************\n\n");

    int i = 10;

    do {
        printf("%d\n", i);
        i--;
    } while (i >= 1);

    return 0;
}
