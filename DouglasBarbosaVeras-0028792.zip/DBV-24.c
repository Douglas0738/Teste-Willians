// DBV-24.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-24 - Verifica se a pessoa ja pode votar                     *");
    printf("\n***************************************************************************\n");

    int idade;

    printf("\nInforme a idade: ");
    scanf("%d", &idade);

    if (idade >= 16) {
        printf("\nVoce JA PODE votar.\n");
    } else {
        printf("\nVoce AINDA NAO PODE votar.\n");
    }

    return 0;
}
