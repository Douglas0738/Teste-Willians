// DBV-52.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-52 - Soma numeros at digitar um multiplo de 10 (do...while) *");
    printf("\n***************************************************************************\n");

    int numero, soma = 0;

    do {
        printf("\nDigite um numero (digite um multiplo de 10 para parar): ");
        scanf("%d", &numero);
        soma += numero;
    } while (numero % 10 != 0);

    printf("\nA soma total e: %d\n", soma);

    return 0;
}
