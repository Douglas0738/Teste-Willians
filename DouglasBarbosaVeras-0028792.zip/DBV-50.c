// DBV-50.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-50 - Exige um numero positivo para deposito usando do...while*");
    printf("\n***************************************************************************\n");

    float valor;

    do {
        printf("\nInforme o valor do deposito (deve ser positivo): ");
        scanf("%f", &valor);
    } while (valor <= 0);

    printf("\nDeposito de R$ %.2f realizado com sucesso!\n", valor);

    return 0;
}
