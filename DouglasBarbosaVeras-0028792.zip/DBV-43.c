// DBV-43.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-43 - Soma os numeros pares entre 1 e 100 utilizando while   *");
    printf("\n***************************************************************************\n");

    int i = 1, soma = 0;

    while (i <= 100) {
        if (i % 2 == 0) {
            soma += i;
        }
        i++;
    }

    printf("\nA soma dos numeros pares entre 1 e 100 e: %d\n", soma);

    return 0;
}
