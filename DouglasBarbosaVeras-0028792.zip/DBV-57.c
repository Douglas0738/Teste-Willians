// DBV-57.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-57 - Central do brinquedo eletronico (urso de pelucia)      *");
    printf("\n***************************************************************************\n");

    char cor;

    /* Como o switch em C nao aceita strings, usamos a letra inicial da cor:
       V = Verde, A = Amarelo, R = Vermelho */
    printf("\nDigite a cor que acendeu (V-Verde, A-Amarelo, R-Vermelho): ");
    scanf(" %c", &cor);

    switch (cor) {
        case 'V':
        case 'v':
            printf("\nO urso diz: \"Vamos brincar la fora!\"\n");
            break;
        case 'A':
        case 'a':
            printf("\nO urso diz: \"Estou ficando com soninho...\"\n");
            break;
        case 'R':
        case 'r':
            printf("\nO urso diz: \"Estou com fome, hora do lanche!\"\n");
            break;
        default:
            printf("\nO urso apenas pisca as luzes (Cor desconhecida).\n");
    }

    return 0;
}
