// DBV-49.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-49 - Pede a senha at acertar utilizando do...while          *");
    printf("\n***************************************************************************\n");

    int senha;
    const int SENHA_CORRETA = 1111;

    do {
        printf("\nDigite a senha de acesso ao laboratorio: ");
        scanf("%d", &senha);
    } while (senha != SENHA_CORRETA);

    printf("\nAcesso liberado!\n");

    return 0;
}
