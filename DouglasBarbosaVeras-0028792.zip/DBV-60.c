// DBV-60.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-60 - Validador de dias uteis das catracas usando switch     *");
    printf("\n***************************************************************************\n");

    int dia;

    printf("\nInforme o dia da semana (1-Domingo, 2-Segunda, ... 7-Sabado): ");
    scanf("%d", &dia);

    switch (dia) {
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            printf("\nDia Util. Acesso liberado para o trabalho.\n");
            break;
        case 1:
        case 7:
            printf("\nFim de Semana. Predio fechado.\n");
            break;
        default:
            printf("\nNumero de dia invalido.\n");
    }

    return 0;
}
