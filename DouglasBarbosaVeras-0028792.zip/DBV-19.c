// DBV-19.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-19 - Ordena tres numeros em ordem crescente                 *");
    printf("\n***************************************************************************\n");

    float n1, n2, n3, aux;

    printf("\nInforme a primeira nota: ");
    scanf("%f", &n1);
    printf("Informe a segunda nota: ");
    scanf("%f", &n2);
    printf("Informe a terceira nota: ");
    scanf("%f", &n3);

    if (n1 > n2) { aux = n1; n1 = n2; n2 = aux; }
    if (n2 > n3) { aux = n2; n2 = n3; n3 = aux; }
    if (n1 > n2) { aux = n1; n1 = n2; n2 = aux; }

    printf("\nOrdem crescente: %.2f, %.2f, %.2f\n", n1, n2, n3);

    return 0;
}
