// DBV-42.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-42 - Conta quantos numeros impares foram digitados          *");
    printf("\n***************************************************************************\n");

    int numero, contador = 0, i = 0;

    while (i < 10) {
        printf("\nDigite o numero %d: ", i + 1);
        scanf("%d", &numero);
        if (numero % 2 != 0) {
            contador++;
        }
        i++;
    }

    printf("\nForam digitados %d numeros impares.\n", contador);

    return 0;
}
