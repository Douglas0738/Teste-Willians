// DBV-37.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-37 - Soma numeros digitados pelo usuario at o digitar 0     *");
    printf("\n***************************************************************************\n");

    int numero, soma = 0;

    printf("\nDigite numeros (digite 0 para parar): ");
    scanf("%d", &numero);

    while (numero != 0) {
        soma += numero;
        printf("Digite outro numero (0 para parar): ");
        scanf("%d", &numero);
    }

    printf("\nA soma total e: %d\n", soma);

    return 0;
}
