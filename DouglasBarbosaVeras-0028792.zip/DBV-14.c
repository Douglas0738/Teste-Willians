// DBV-14.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-14 - Verifica o tipo de triangulo (Equilatero/Isosceles/Escaleno)*");
    printf("\n***************************************************************************\n");

    float lado1, lado2, lado3;

    printf("\nInforme o primeiro lado do triangulo: ");
    scanf("%f", &lado1);
    printf("Informe o segundo lado do triangulo: ");
    scanf("%f", &lado2);
    printf("Informe o terceiro lado do triangulo: ");
    scanf("%f", &lado3);

    if (lado1 == lado2 && lado2 == lado3) {
        printf("\nO triangulo eh EQUILATERO (todos os lados sao iguais).\n");
    } else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3) {
        printf("\nO triangulo eh ISOSCELES (dois lados sao iguais).\n");
    } else {
        printf("\nO triangulo eh ESCALENO (todos os lados sao diferentes).\n");
    }

    return 0;
}
