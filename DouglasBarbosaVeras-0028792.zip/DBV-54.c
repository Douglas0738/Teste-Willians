// DBV-54.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-54 - Valida um nivel de dificuldade entre 1 e 5             *");
    printf("\n***************************************************************************\n");

    int nivel;

    do {
        printf("\nEscolha o nivel de dificuldade (1 a 5): ");
        scanf("%d", &nivel);
    } while (nivel < 1 || nivel > 5);

    printf("\nNivel de dificuldade %d selecionado!\n", nivel);

    return 0;
}
