// DBV-56.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-56 - Menu do totem de autoatendimento (Fast-Food Digital)   *");
    printf("\n***************************************************************************\n");

    int combo;

    printf("\n1 - Combo Hamburguer + Batata + Refri\n");
    printf("2 - Combo Pizza Brotinho + Refri\n");
    printf("3 - Combo Salada + Suco Natural\n");
    printf("4 - Combo Balde de Frango + Molho\n");
    printf("\nDigite o numero do combo escolhido: ");
    scanf("%d", &combo);

    switch (combo) {
        case 1:
            printf("\nCombo Hamburguer + Batata + Refri - R$ 30,00\n");
            break;
        case 2:
            printf("\nCombo Pizza Brotinho + Refri - R$ 25,00\n");
            break;
        case 3:
            printf("\nCombo Salada + Suco Natural - R$ 22,00\n");
            break;
        case 4:
            printf("\nCombo Balde de Frango + Molho - R$ 35,00\n");
            break;
        default:
            printf("\nOpcao invalida! Escolha de 1 a 4.\n");
    }

    return 0;
}
