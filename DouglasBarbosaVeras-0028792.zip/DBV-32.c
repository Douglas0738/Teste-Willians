// DBV-32.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-32 - Exibe o quadrado dos numeros de 1 a 10 usando for      *");
    printf("\n***************************************************************************\n\n");

    int i;

    for (i = 1; i <= 10; i++) {
        printf("%d ao quadrado = %d\n", i, i * i);
    }

    return 0;
}
