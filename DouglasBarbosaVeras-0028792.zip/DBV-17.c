// DBV-17.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-17 - Sensor de altura da montanha-russa do parque tematico  *");
    printf("\n***************************************************************************\n");

    float altura;
    const float ALTURA_MINIMA = 140.0;

    printf("\nInforme a altura da crianca em centimetros: ");
    scanf("%f", &altura);

    if (altura >= ALTURA_MINIMA) {
        printf("\nLuz VERDE: acesso liberado! Pode entrar no brinquedo.\n");
    } else {
        printf("\nLuz VERMELHA: acesso barrado! Altura insuficiente.\n");
    }

    return 0;
}
