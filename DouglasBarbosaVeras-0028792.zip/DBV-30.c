// DBV-30.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-30 - Calcula o fatorial de um numero utilizando for         *");
    printf("\n***************************************************************************\n");

    int numero, i;
    long long fatorial = 1;

    printf("\nInforme um numero: ");
    scanf("%d", &numero);

    for (i = 1; i <= numero; i++) {
        fatorial *= i;
    }

    printf("\nO fatorial de %d e: %lld\n", numero, fatorial);

    return 0;
}
