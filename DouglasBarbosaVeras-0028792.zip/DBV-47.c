// DBV-47.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-47 - Exibe a tabuada de um numero utilizando do...while     *");
    printf("\n***************************************************************************\n");

    int numero, i = 1;

    printf("\nInforme um numero: ");
    scanf("%d", &numero);

    printf("\nTabuada do %d:\n", numero);
    do {
        printf("%d x %d = %d\n", numero, i, numero * i);
        i++;
    } while (i <= 10);

    return 0;
}
