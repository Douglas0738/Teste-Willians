// DBV-44.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-44 - Conta quantos digitos um numero possui usando while    *");
    printf("\n***************************************************************************\n");

    int numero, contador = 0;

    printf("\nInforme um numero positivo: ");
    scanf("%d", &numero);

    if (numero == 0) {
        contador = 1;
    } else {
        while (numero > 0) {
            numero /= 10;
            contador++;
        }
    }

    printf("\nO numero possui %d digito(s).\n", contador);

    return 0;
}
