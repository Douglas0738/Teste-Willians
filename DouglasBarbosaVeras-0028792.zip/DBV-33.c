// DBV-33.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-33 - Lista os multiplos de 3 entre 1 e 30 usando for        *");
    printf("\n***************************************************************************\n\n");

    int i;

    for (i = 1; i <= 30; i++) {
        if (i % 3 == 0) {
            printf("%d\n", i);
        }
    }

    return 0;
}
