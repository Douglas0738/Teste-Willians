// DBV-21.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-21 - Verifica se um numero e positivo, negativo ou zero     *");
    printf("\n***************************************************************************\n");

    float numero;

    printf("\nInforme um numero: ");
    scanf("%f", &numero);

    if (numero > 0) {
        printf("\nO numero eh POSITIVO (lucro).\n");
    } else if (numero < 0) {
        printf("\nO numero eh NEGATIVO (prejuizo).\n");
    } else {
        printf("\nO numero eh ZERO.\n");
    }

    return 0;
}
