// DBV-15.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-15 - Calcula quantas caixas cabem dentro do caminhao        *");
    printf("\n***************************************************************************\n");

    float alturaCaminhao, larguraCaminhao, comprimentoCaminhao;
    float alturaCaixa, larguraCaixa, comprimentoCaixa;

    printf("\nInforme a altura do caminhao em metros: ");
    scanf("%f", &alturaCaminhao);
    printf("Informe a largura do caminhao em metros: ");
    scanf("%f", &larguraCaminhao);
    printf("Informe o comprimento do caminhao em metros: ");
    scanf("%f", &comprimentoCaminhao);

    printf("\nInforme a altura da caixa em centimetros: ");
    scanf("%f", &alturaCaixa);
    printf("Informe a largura da caixa em centimetros: ");
    scanf("%f", &larguraCaixa);
    printf("Informe o comprimento da caixa em centimetros: ");
    scanf("%f", &comprimentoCaixa);

    /* Converte as medidas do caminhao de metros para centimetros */
    float alturaCaminhaoCm = alturaCaminhao * 100;
    float larguraCaminhaoCm = larguraCaminhao * 100;
    float comprimentoCaminhaoCm = comprimentoCaminhao * 100;

    int caixasAltura = (int)(alturaCaminhaoCm / alturaCaixa);
    int caixasLargura = (int)(larguraCaminhaoCm / larguraCaixa);
    int caixasComprimento = (int)(comprimentoCaminhaoCm / comprimentoCaixa);

    int totalCaixas = caixasAltura * caixasLargura * caixasComprimento;

    printf("\nCabem %d caixas dentro do caminhao.\n", totalCaixas);

    return 0;
}
