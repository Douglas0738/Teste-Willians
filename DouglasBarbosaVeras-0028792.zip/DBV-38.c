// DBV-38.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-38 - Pede a senha repetidamente at acertar usando while     *");
    printf("\n***************************************************************************\n");

    int senha;
    const int SENHA_CORRETA = 1234;

    printf("\nDigite a senha: ");
    scanf("%d", &senha);

    while (senha != SENHA_CORRETA) {
        printf("Senha incorreta! Tente novamente: ");
        scanf("%d", &senha);
    }

    printf("\nSenha correta! Acesso permitido.\n");

    return 0;
}
