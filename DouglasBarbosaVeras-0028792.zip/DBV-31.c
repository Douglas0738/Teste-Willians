// DBV-31.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-31 - Contagem regressiva de 10 a 1 utilizando for           *");
    printf("\n***************************************************************************\n\n");

    int i;

    for (i = 10; i >= 1; i--) {
        printf("%d\n", i);
    }

    return 0;
}
