// DBV-55.c
#include <stdio.h>

int main() {

    printf("\n***************************************************************************");
    printf("\n* Aluno: DOUGLAS BARBOSA VERAS - RA  0028792                                *");
    printf("\n* Programa DBV-55 - Mostra o maior numero positivo at digitar um negativo  *");
    printf("\n***************************************************************************\n");

    int numero, maior = -1;

    do {
        printf("\nDigite um numero (digite um valor negativo para parar): ");
        scanf("%d", &numero);
        if (numero >= 0 && numero > maior) {
            maior = numero;
        }
    } while (numero >= 0);

    printf("\nO maior numero positivo informado foi: %d\n", maior);

    return 0;
}
